The Selenium Starter-kit provides a ready to use framework for automation of web applications using WebDriver 2.0 & supports common testing frameworks like 
-	TestNg, 
-	Junit
-	Bdd based JBehave.
-	Serenity

The code base consists of packages and classes, which allow and assist anyone to start automation of web based applications using Java as the base language. It can be used to test any applications running on browsers like Chrome, Firefox, Internet Explorer, etc. as well as on mobile (Android & iPhone).
Please refer to the extension documentation on the [wiki](http://10.30.5.72/test-automation/selenium-starter-kit/wikis/home).
