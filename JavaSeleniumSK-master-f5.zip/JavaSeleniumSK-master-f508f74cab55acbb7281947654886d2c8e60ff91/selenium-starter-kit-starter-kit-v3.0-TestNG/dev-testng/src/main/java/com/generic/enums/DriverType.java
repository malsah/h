package com.generic.enums;

public enum DriverType {
	LOCAL, MOBILE, REMOTE, SAUCE

};


