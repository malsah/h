package com.generic.exceptions;

public class URLNavigationException extends Exception {

    public URLNavigationException(String message, Throwable cause) {
        super(message, cause);
    }
}
