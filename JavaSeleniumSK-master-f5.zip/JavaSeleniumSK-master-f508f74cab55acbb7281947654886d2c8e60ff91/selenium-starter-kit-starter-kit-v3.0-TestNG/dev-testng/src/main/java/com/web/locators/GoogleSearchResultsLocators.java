package com.web.locators;

import org.openqa.selenium.By;

public interface GoogleSearchResultsLocators {
    public static final By SEARCH_RESULT = By.cssSelector("h3.r");


}
